"""
Package for DjangoStart.
"""
